// Hamburger Menu Toggle
document.addEventListener('DOMContentLoaded', () => {
    const hamburger = document.getElementById('hamburger');
    const navMenu = document.getElementById('navMenu');
    const navLinks = document.querySelectorAll('.nav-link');

    // Toggle menu
    hamburger.addEventListener('click', () => {
        hamburger.classList.toggle('active');
        navMenu.classList.toggle('active');
    });

    // Close menu when link is clicked
    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            hamburger.classList.remove('active');
            navMenu.classList.remove('active');
        });
    });

    // Close menu when clicking outside
    document.addEventListener('click', (e) => {
        if (!e.target.closest('.navbar')) {
            hamburger.classList.remove('active');
            navMenu.classList.remove('active');
        }
    });

    // Active link highlighting and smooth scroll
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            const href = link.getAttribute('href');

            // Only prevent default for anchor links
            if (href.startsWith('#')) {
                e.preventDefault();

                // Remove active class from all links
                navLinks.forEach(l => l.classList.remove('active'));

                // Add active class to clicked link
                link.classList.add('active');

                // Smooth scroll to section
                const targetId = href.substring(1);
                const targetSection = document.getElementById(targetId);

                if (targetSection) {
                    targetSection.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            }
        });
    });

    // Update active link on scroll
    window.addEventListener('scroll', () => {
        let current = '';
        const sections = document.querySelectorAll('section[id]');

        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            const sectionHeight = section.clientHeight;

            if (pageYOffset >= sectionTop - 200) {
                current = section.getAttribute('id');
            }
        });

        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href') === `#${current}`) {
                link.classList.add('active');
            }
        });
    });
});

// Typed Text
document.addEventListener('DOMContentLoaded', () => {
    const typed = new Typed('.typing-text', {
        strings: ['Frontend Developer', 'Backend Developer', 'Web Developer', 'Telecom Engineer', 'Programmer', 'Graphic Designer',
            'Digital Marketer', 'AI Enthusiast', 'Social Media Manager', 'Content Creator', 'Project Manager',
            'Problem Solver'],
        typeSpeed: 70,
        backSpeed: 70,
        backDelay: 1000,
        loop: true,
    });
});

document.addEventListener("DOMContentLoaded", function () {
    const aboutSection = document.querySelector(".about");
    const observer = new IntersectionObserver(
        (entries) => {
            entries.forEach((entry) => {
                if (entry.isIntersecting) {
                    entry.target.classList.add("fade-in");
                }
            });
        },
        { threshold: 0.5 }
    );
    if (aboutSection) {
        observer.observe(aboutSection);
    }
});


// Contact Form Validation and Interaction
document.addEventListener('DOMContentLoaded', () => {
    const contactForm = document.querySelector('.contact-form');
    const formInputs = document.querySelectorAll('.form-input');
    const submitBtn = document.querySelector('.submit-btn');

    if (!contactForm) return;

    // Real-time validation
    formInputs.forEach(input => {
        input.addEventListener('blur', () => validateField(input));
        input.addEventListener('input', () => {
            if (input.classList.contains('error')) {
                validateField(input);
            }
        });
    });

    // Form submission
    contactForm.addEventListener('submit', (e) => {
        let isValid = true;
        formInputs.forEach(input => {
            if (!validateField(input)) {
                isValid = false;
            }
        });

        if (!isValid) {
            e.preventDefault();
        } else {
            // Allow form to submit to Formspree
            submitBtn.innerHTML = '<span class="btn-text">Sending...</span><span class="btn-icon"><i class="fas fa-spinner fa-spin"></i></span>';
            submitBtn.disabled = true;
        }
    });

    function validateField(input) {
        const field = input.parentElement;
        const errorElement = field.querySelector('.form-error');
        let isValid = true;
        let errorMessage = '';

        if (input.type === 'email') {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(input.value)) {
                isValid = false;
                errorMessage = 'Please enter a valid email address';
            }
        } else if (input.type === 'tel') {
            const phoneRegex = /^[\d\s\-\+\(\)]+$/;
            if (input.value && !phoneRegex.test(input.value)) {
                isValid = false;
                errorMessage = 'Please enter a valid phone number';
            }
        } else if (input.value.trim().length === 0) {
            isValid = false;
            errorMessage = 'This field is required';
        }

        if (!isValid) {
            field.classList.add('error');
            errorElement.textContent = errorMessage;
        } else {
            field.classList.remove('error');
            errorElement.textContent = '';
        }

        return isValid;
    }
});


// Scroll to Top Button
document.addEventListener('DOMContentLoaded', () => {
    const scrollBtn = document.querySelector('.scroll-btn');
    const scrollToTop = document.querySelector('.scroll-to-top');

    if (!scrollBtn) return;

    // Show/hide scroll button
    window.addEventListener('scroll', () => {
        if (window.scrollY > 300) {
            scrollToTop.classList.add('show');
        } else {
            scrollToTop.classList.remove('show');
        }
    });

    // Scroll to top on click
    scrollBtn.addEventListener('click', () => {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });
});

// Newsletter Form
document.addEventListener('DOMContentLoaded', () => {
    const newsletterForm = document.querySelector('.newsletter-form');
    const newsletterInput = document.querySelector('.newsletter-input');
    const newsletterBtn = document.querySelector('.newsletter-btn');

    if (!newsletterForm) return;

    newsletterForm.addEventListener('submit', async (e) => {
        e.preventDefault();

        const email = newsletterInput.value.trim();
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (!emailRegex.test(email)) {
            newsletterInput.style.borderColor = '#ff6b6b';
            return;
        }

        // Show loading state
        const originalText = newsletterBtn.innerHTML;
        newsletterBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
        newsletterBtn.disabled = true;

        try {
            // Send to Formspree
            const response = await fetch('https://formspree.io/f/mnjognjl', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    email: email,
                    _subject: 'New Newsletter Subscription'
                })
            });

            if (response.ok) {
                // Success state
                newsletterBtn.innerHTML = '<i class="fas fa-check"></i>';
                newsletterBtn.style.background = 'linear-gradient(135deg, #00FFA3, #00D1FF)';

                setTimeout(() => {
                    newsletterForm.reset();
                    newsletterBtn.innerHTML = originalText;
                    newsletterBtn.style.background = '';
                    newsletterInput.style.borderColor = '';
                    newsletterBtn.disabled = false;
                }, 2000);
            } else {
                throw new Error('Submission failed');
            }
        } catch (error) {
            // Error state
            newsletterInput.style.borderColor = '#ff6b6b';
            newsletterBtn.innerHTML = '<i class="fas fa-exclamation"></i>';
            newsletterBtn.style.background = '#ff6b6b';

            setTimeout(() => {
                newsletterBtn.innerHTML = originalText;
                newsletterBtn.style.background = '';
                newsletterBtn.disabled = false;
            }, 2000);
        }
    });

    // Reset border color on input
    newsletterInput.addEventListener('input', () => {
        newsletterInput.style.borderColor = '';
    });
});

// Footer Links Smooth Scroll
document.addEventListener('DOMContentLoaded', () => {
    const footerLinks = document.querySelectorAll('.footer-links a');

    footerLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            const href = link.getAttribute('href');
            if (href.startsWith('#')) {
                e.preventDefault();
                const target = document.querySelector(href);
                if (target) {
                    target.scrollIntoView({ behavior: 'smooth' });
                }
            }
        });
    });
});


// Service Modal Functionality
document.addEventListener('DOMContentLoaded', () => {
    const serviceData = {
        'web-dev': {
            icon: 'bi-code-slash',
            title: 'Web Development',
            subtitle: 'Professional web solutions',
            overview: 'I create stunning, responsive Websites that combine beautiful design with powerful functionality. From concept to deployment, I ensure every project is optimized for performance, user experience, and search engines.',
            features: [
                'Responsive Design',
                'Fast Performance',
                'SEO Optimized',
                'Mobile-First Approach',
                'Cross-Browser Compatible',
                'Accessibility Compliant'
            ],
            technologies: ['HTML5', 'CSS', 'JavaScript', 'React', 'Node.js', 'PHP', 'MySQL', 'Python']
        },
        'graphic-design': {
            icon: 'bi-pencil-fill',
            title: 'Graphic Design',
            subtitle: 'Creative visual solutions',
            overview: 'With a creative touch, I provide comprehensive Graphic Design services to enhance the visual appeal of your brand. From logos to marketing materials, I create designs that captivate and communicate your message effectively.',
            features: [
                'Logo Design',
                'Brand Identity',
                'Marketing Materials',
                'Social Media Graphics',
                'UI/UX Design',
                'Print Design'
            ],
            technologies: ['Adobe Photoshop', 'Adobe Illustrator', 'Premier Pro', 'Canva', 'YouCut', 'CapCut']
        },
        'digital-marketing': {
            icon: 'bi-bar-chart-line-fill',
            title: 'Digital Marketing',
            subtitle: 'Growth-driven marketing strategies',
            overview: 'I offer comprehensive Digital Marketing solutions to help Businesses increase their online presence and reach a wider audience. Through strategic planning and creative execution, I drive engagement and conversions.',
            features: [
                'Social Media Marketing',
                'Content Creation',
                'SEO Strategy',
                'Email Marketing',
                'Analytics & Reporting',
                'Campaign Management'
            ],
            technologies: ['Facebook Ads', 'Instagram', 'TikTok', 'LinkedIn', 'Google Analytics', 'Mailchimp', 'Canva', 'Buffer', 'Hootsuite']
        }
    };

    const modalOverlay = document.getElementById('serviceModalOverlay');
    const modalClose = document.getElementById('modalClose');
    const readMoreButtons = document.querySelectorAll('.service-read-more');

    // Open Modal
    readMoreButtons.forEach(button => {
        button.addEventListener('click', (e) => {
            e.preventDefault();
            const serviceId = button.getAttribute('data-service');
            const service = serviceData[serviceId];

            if (service) {
                updateModal(service);
                modalOverlay.classList.add('active');
                document.body.style.overflow = 'hidden';
            }
        });
    });

    // Close Modal
    modalClose.addEventListener('click', closeModal);
    modalOverlay.addEventListener('click', (e) => {
        if (e.target === modalOverlay) {
            closeModal();
        }
    });

    // Close on Escape key
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && modalOverlay.classList.contains('active')) {
            closeModal();
        }
    });

    // Close modal when CTA buttons are clicked
    const ctaButtons = document.querySelectorAll('.cta-btn');
    ctaButtons.forEach(button => {
        button.addEventListener('click', () => {
            closeModal();
        });
    });

    function updateModal(service) {
        // Update Icon
        const modalIcon = document.getElementById('modalIcon');
        modalIcon.innerHTML = `<i class="bi ${service.icon}"></i>`;

        // Update Title and Subtitle
        document.getElementById('modalTitle').textContent = service.title;
        document.getElementById('modalSubtitle').textContent = service.subtitle;

        // Update Overview
        document.getElementById('modalOverview').textContent = service.overview;

        // Update Features
        const featuresList = document.getElementById('modalFeatures');
        featuresList.innerHTML = service.features
            .map(feature => `<li><i class="bi bi-check-circle"></i> ${feature}</li>`)
            .join('');

        // Update Technologies
        const techStack = document.getElementById('modalTech');
        techStack.innerHTML = service.technologies
            .map(tech => `<span class="tech-badge">${tech}</span>`)
            .join('');

        // Scroll to top of modal
        const modal = document.querySelector('.service-modal');
        modal.scrollTop = 0;
    }

    function closeModal() {
        modalOverlay.classList.remove('active');
        document.body.style.overflow = 'auto';
    }
});




// ===== TESTIMONIALS CAROUSEL =====
document.addEventListener('DOMContentLoaded', () => {
    const testimonials = [
        {
            quote: 'Working with Abdulmajeed transformed our entire brand perception. The attention to detail and creative vision exceeded every expectation we had to Our Bakery.',
            author: 'Naomi Mshana',
            role: 'CEO, NAM CAKES',
            initials: 'NM'
        },
        {
            quote: 'TECH-X AI Assistant, Powerful Voice Command AI Assistance completely chnged how we interact with Technology. Speaking commands feels Natural, Fast and Incredibly Accurate, It Controlling Our Entire Workflow with just a Voice ',
            author: 'Festo Magembe',
            role: 'Founder, ProjectUnite',
            initials: 'FM'
        },
        {
            quote: 'Working with Abdulmajeed was game-changer for our Business. He did not just Build Website but He crafted a High Performing Digital Experiences that evaluated Our Brand. ',
            author: 'Ally Buruani',
            role: 'CEO, Polepole Trekking & Safaris Company',
            initials: 'AB'
        },
        {
            quote: 'Abdulmajeed brought our vision to life in ways we never imagined possible. The result was a digital experience that truly resonates with our audience.',
            author: 'Brian Mchuma',
            role: 'Head of Marketing, Mchuma Builder Ass',
            initials: 'BM'
        },
        {
            quote: 'Abdulmajeed demostrates a deep Awareness of currently Technologies. Tech-X AI Asistant Reflects a Strong Understanding of Modern AI Trends, Delivering a Solution that Feels relevant, Forward-thinking and Practical.',
            author: 'Festo ProjectUnite ',
            role: 'CEO, ProjectUnite',
            initials: 'FM'
        },
        {
            quote: 'From concept to execution, Abdulmajeed demonstrated exceptional creativity and professionalism. Our brand has never looked better or felt more authentic.',
            author: 'James Masalu',
            role: 'Founder & CEO, IB Stationery',
            initials: 'JM'
        }
    ];

    let currentTestimonial = 0;
    let autoRotateInterval;
    let isUpdating = false;

    const slider = document.getElementById('testimonialSlider');
    if (!slider) return;

    const card = slider.querySelector('.testimonial-card');
    const dots = document.querySelectorAll('.dot');

    // Function to update testimonial
    function updateTestimonial(index) {
        // Prevent multiple simultaneous updates
        if (isUpdating) return;
        isUpdating = true;

        // Fade out
        card.style.opacity = 0;
        card.style.transform = 'translateY(20px)';

        setTimeout(() => {
            const t = testimonials[index];

            // Update content
            card.querySelector('.testimonial-profile').textContent = t.initials;
            card.querySelector('.testimonial-quote').textContent = t.quote;
            card.querySelector('.testimonial-author').textContent = t.author;
            card.querySelector('.testimonial-role').textContent = t.role;

            // Fade in
            card.style.opacity = 1;
            card.style.transform = 'translateY(0)';

            // Update dots
            dots.forEach((dot, i) => {
                dot.classList.toggle('active', i === index);
            });

            // Allow next update
            isUpdating = false;
        }, 300);
    }

    // Auto-rotate testimonials
    function startAutoRotate() {
        // Clear any existing interval first to prevent stacking
        if (autoRotateInterval) {
            clearInterval(autoRotateInterval);
        }
        autoRotateInterval = setInterval(() => {
            currentTestimonial = (currentTestimonial + 1) % testimonials.length;
            updateTestimonial(currentTestimonial);
        }, 10000);
    }

    // Manual navigation with dots
    dots.forEach(dot => {
        dot.addEventListener('click', () => {
            if (autoRotateInterval) {
                clearInterval(autoRotateInterval);
            }
            currentTestimonial = parseInt(dot.dataset.index);
            updateTestimonial(currentTestimonial);
            startAutoRotate();
        });
    });

    // Add touch support for mobile devices
    let touchStartX = 0;
    let touchEndX = 0;

    if (card) {
        card.addEventListener('touchstart', (e) => {
            touchStartX = e.changedTouches[0].screenX;
        }, { passive: true });

        card.addEventListener('touchend', (e) => {
            touchEndX = e.changedTouches[0].screenX;
            handleSwipe();
        }, { passive: true });
    }

    function handleSwipe() {
        const swipeThreshold = 50;
        const diff = touchStartX - touchEndX;

        if (Math.abs(diff) > swipeThreshold) {
            if (autoRotateInterval) {
                clearInterval(autoRotateInterval);
            }

            if (diff > 0) {
                // Swipe left - next testimonial
                currentTestimonial = (currentTestimonial + 1) % testimonials.length;
            } else {
                // Swipe right - previous testimonial
                currentTestimonial = (currentTestimonial - 1 + testimonials.length) % testimonials.length;
            }

            updateTestimonial(currentTestimonial);
            startAutoRotate();
        }
    }

    // Start auto-rotation
    startAutoRotate();

    // Pause on hover (desktop only)
    const testimonialSection = document.querySelector('.testimonials-section');
    if (testimonialSection && window.innerWidth > 768) {
        testimonialSection.addEventListener('mouseenter', () => {
            if (autoRotateInterval) {
                clearInterval(autoRotateInterval);
            }
        });

        testimonialSection.addEventListener('mouseleave', () => {
            startAutoRotate();
        });
    }

    // Handle visibility change (pause when tab is hidden)
    document.addEventListener('visibilitychange', () => {
        if (document.hidden) {
            if (autoRotateInterval) {
                clearInterval(autoRotateInterval);
            }
        } else {
            startAutoRotate();
        }
    });
});
